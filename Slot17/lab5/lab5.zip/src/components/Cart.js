import React, { useContext, useState } from "react";
import Button from 'react-bootstrap/Button';
import { CartContext } from "../context/CartContext";

const Cart = () => {
  const { cartItems, removeFromCart, clearCart, totalValue } = useContext(CartContext);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleCheckout = () => {
    // Xử lý thanh toán ở đây (có thể gọi API nếu cần)
    clearCart();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 10000); // Ẩn thông báo sau 10s
  };

  return (
    <div>
      <h2 className="mb-3">Giỏ hàng</h2>
      {showSuccess && (
        <div className="alert alert-success" role="alert">
          Thanh toán thành công! Cảm ơn bạn đã đặt hàng.
        </div>
      )}
      <div className="card shadow-sm">
        <div className="card-body">
          {cartItems.length === 0 ? (
            <p>Giỏ hàng của bạn đang trống.</p>
          ) : (
            <>
              <ul className="list-group mb-3">
                {cartItems.map((item) => (
                  <li key={item.id} className="list-group-item d-flex justify-content-between align-items-center">
                    <span>{item.name} - ${item.price}</span>
                    <Button variant="danger" size="sm" onClick={() => removeFromCart(item.id)}>Xóa</Button>
                  </li>
                ))}
              </ul>
              <p>{`Tổng số món: ${cartItems.length}`}</p>
              <p>{`Tổng giá trị: $${totalValue}`}</p>
              <Button variant="warning" className="me-2" onClick={clearCart}>Xóa tất cả</Button>
              <Button variant="success" onClick={handleCheckout}>Xác nhận đơn hàng</Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;
